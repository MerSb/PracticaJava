public class Casa extends Propiedad {

    private double impuestoBase;

    public double getImpuestoBase() {
        return impuestoBase;
    }

    public void setImpuestoBase(double impuestoBase) {
        this.impuestoBase = impuestoBase;
    }

    @Override
    public double calcularImpuesto() {

        double total = 0;

        if (getCalle().equals("Av. San Martin")) {
            total += impuestoBase * 1.1;
        } else {
            return impuestoBase;
        }
        return total;
    }

    @Override
    public String toString() {
        return "Casa{" +
                "impuestoBase=" + impuestoBase +
                '}';
    }
}


