import java.util.ArrayList;
import java.util.List;

public class BarrioCerrado extends Propiedad {

 private double factor;
 private List<Casa> casas;

    public BarrioCerrado() {
        this.factor = factor;
        this.casas = new ArrayList<>();
    }

    public double getFactor() {
        return factor;
    }

    public void setFactor(double factor) {
        this.factor = factor;
    }

    public List<Casa> getCasas() {
        return casas;
    }

    public void setCasas(List<Casa> casas) {
        this.casas = casas;
    }

    @Override
    public double calcularImpuesto() {
        double total=0;
        for(Casa casa: casas){
            total += casa.getImpuestoBase()*getFactor();
        }
    return total;

    }

    @Override
    public String toString() {
        return "BarrioCerrado{" +
                "factor=" + factor +
                ", casas=" + casas +
                '}';
    }
}
