public class PropiedadFactory {

    private static PropiedadFactory factory = null;

    public static final String Casa ="CASA";
    public static final String Casas ="BARRIO CERRADO";
    public static final String municipio ="MUNICIPIO";

    public PropiedadFactory() {}

    public static PropiedadFactory getInstancia(){
    if (factory == null)
        factory = new PropiedadFactory();
    return factory;
    }
    public Propiedad createPropiedad(String tipo){
        switch (tipo) {
            case PropiedadFactory.Casa -> new Casa();
                case PropiedadFactory.Casas -> new BarrioCerrado();
                case PropiedadFactory.municipio -> new Municipio();
        }
        return null;
    }
}
