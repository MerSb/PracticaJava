import java.util.ArrayList;
import java.util.List;

public class Municipio {
    private List<Propiedad> propiedades;

    public Municipio() {
        this.propiedades = new ArrayList<>();
    }

    public void mostrarPropiedades (){

            for (Propiedad propiedad: propiedades ) {
                System.out.println(propiedad.toString());
            }
        }

    }


