import java.util.ArrayList;
import java.util.List;

public abstract class Propiedad {

    private String calle;
    private int numero;



    public Propiedad(String calle, int numero) {
        this.calle = calle;
        this.numero = numero;

    }

    public Propiedad() {

    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public abstract double calcularImpuesto ();

    @Override
    public String toString() {
        return "Propiedad{" +
                "calle='" + calle + '\'' +
                ", numero=" + numero +
                '}';
    }
}

