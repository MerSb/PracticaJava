
public class Main {

    public static void main(String[] args) {
        PropiedadFactory propiedadfactory= new PropiedadFactory();

        Propiedad Casa1= (Casa)PropiedadFactory.getInstancia().createPropiedad("CASA");
        Casa1.setNumero(130);
        Casa1.setCalle("Av. San Martin");
        ((Casa) Casa1).setImpuestoBase(500.00);

    }
}
